﻿Public Class ucComboboxAutoCompleteCell
    Inherits DataGridViewComboBoxCell

    Public Sub New()
        MyBase.New()
        DisplayStyle = DataGridViewComboBoxDisplayStyle.ComboBox
        FlatStyle = FlatStyle.Flat
    End Sub
    Public Overrides ReadOnly Property EditType As Type
        Get
            Return GetType(ucComboboxAutoComplete)
        End Get
    End Property
    Public Overrides Sub InitializeEditingControl(ByVal rowIndex As Integer,
        ByVal initialFormattedValue As Object,
        ByVal dataGridViewCellStyle As DataGridViewCellStyle)
        ' Call base...
        MyBase.InitializeEditingControl(rowIndex, initialFormattedValue, dataGridViewCellStyle)

        Dim ctl As ucComboboxAutoComplete = CType(DataGridView.EditingControl, ucComboboxAutoComplete)
        ctl.DropDownStyle = ComboBoxStyle.DropDown
        ctl.AutoCompleteMode = AutoCompleteMode.None

        ' Make sure you have an instance...
        If ctl IsNot Nothing Then
            Dim ucColumn As ucComboboxAutoCompleteColumn
            ucColumn = TryCast(OwningColumn, ucComboboxAutoCompleteColumn)

            If ucColumn IsNot Nothing Then
                ctl.BeginUpdate()
                ctl.AllowForItemsOnly = True
                ctl.AllowUserToAdd = False
                ctl.DropDownStyle = ComboBoxStyle.DropDown
                ctl.synonymMode_SetMode()
                For Each val As String In ucColumn.Items
                    ctl.synonymMode_AddItem(val, val)
                Next
                ctl.Text = initialFormattedValue
                ctl.EndUpdate()
                ctl.showDropDown()
            End If
        End If

    End Sub

    Public Sub SetData(ByRef sActualText As String(), sID As String(), sSynonymList As String())
        Dim ctl As ucComboboxAutoComplete = CType(DataGridView.EditingControl, ucComboboxAutoComplete)
        For i As Integer = 0 To sActualText.Count - 1
            ctl.synonymMode_AddItem(sActualText(i), sID(i), sSynonymList(i))
        Next
    End Sub

End Class
