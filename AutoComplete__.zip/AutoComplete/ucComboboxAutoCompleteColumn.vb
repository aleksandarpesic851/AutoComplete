﻿Imports System.ComponentModel
Imports System.Drawing.Design

Public Class ucComboboxAutoCompleteColumn
    Inherits DataGridViewComboBoxColumn

    Private bAllowForItemsOnly As Boolean = True
    <DefaultValue(True)> <Browsable(False)>
    Public Property AllowForItemsOnly() As Boolean
        Get
            Return bAllowForItemsOnly
        End Get
        Set(value As Boolean)
            bAllowForItemsOnly = value
        End Set
    End Property

    Private bAllowUserToAdd As Boolean = True
    <DefaultValue(True)> <Browsable(False)>
    Public Property AllowUserToAddItem() As Boolean
        Get
            Return bAllowUserToAdd
        End Get
        Set(value As Boolean)
            bAllowUserToAdd = value
        End Set
    End Property
    Public Overrides Property CellTemplate As DataGridViewCell
        Get
            Return MyBase.CellTemplate
        End Get
        Set(ByVal value As DataGridViewCell)
            If value IsNot Nothing AndAlso Not value.[GetType]().IsAssignableFrom(GetType(ucComboboxAutoCompleteCell)) Then
                Throw New InvalidCastException("Must be a ucComboboxAutoCompleteCell")
            End If
            MyBase.CellTemplate = value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        DisplayMember = String.Empty
        ValueMember = String.Empty
        DisplayStyle = DataGridViewComboBoxDisplayStyle.ComboBox
        MyBase.CellTemplate = New ucComboboxAutoCompleteCell()
    End Sub

End Class